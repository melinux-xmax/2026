# Liste de Noël de Melinux — mise en ligne sur Netlify

Tu n'as besoin d'aucune connaissance technique. Compte environ 10 minutes.
Tes proches ouvriront simplement le lien : **aucun compte n'est demandé**.

## 1. Mettre les fichiers sur GitHub
1. Crée un compte gratuit sur https://github.com (si tu n'en as pas).
2. Clique sur **+** (en haut à droite) puis **New repository**. Nom : `liste-noel`. Laisse **Private**. Clique **Create repository**.
3. Sur la page du dépôt, clique **uploading an existing file**.
4. Dézippe le dossier que je t'ai envoyé, puis glisse **tout son contenu** (dossiers `public`, `netlify`, et les fichiers `netlify.toml`, `package.json`) dans la page.
   Important : les dossiers doivent rester tels quels.
5. Clique **Commit changes**.

## 2. Publier avec Netlify
1. Crée un compte gratuit sur https://app.netlify.com (choisis « Se connecter avec GitHub »).
2. **Add new project** → **Import an existing project** → **GitHub** → choisis `liste-noel`.
3. Ne change aucun réglage, clique **Deploy**. Attends 1 à 2 minutes.

## 3. Choisir ton code secret (indispensable)
1. Dans Netlify : **Project configuration** → **Environment variables** → **Add a variable**.
2. Nom : `ADMIN_CODE` — Valeur : le code que tu veux (ex. une phrase que tu retiens). Enregistre.
3. Va dans **Deploys** → **Trigger deploy** → **Deploy project without cache** (le code n'est pris en compte qu'après un nouveau déploiement).

## 4. Utiliser
- Le lien de ta liste est affiché en haut du projet Netlify (`xxx.netlify.app`). Tu peux le renommer dans **Project configuration → Change project name**.
- Pour modifier ta liste : en bas de la liste, touche **Espace Melinux** et entre ton code.
- Ne donne jamais ce code à ta famille. Elle n'en a pas besoin pour réserver.

## À savoir
- Une réservation est liée à l'appareil de la personne : elle peut l'annuler depuis le même téléphone/navigateur. Si elle change d'appareil, c'est toi qui peux « Rendre disponible » depuis ton espace.
- Netlify gratuit suffit largement pour cet usage.
