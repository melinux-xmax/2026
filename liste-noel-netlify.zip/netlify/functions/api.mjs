// Serveur de la liste de Noël de Melinux (Netlify Functions + Netlify Blobs).
// Toutes les routes commencent par /api.
import { getStore } from "@netlify/blobs";
import { createHash, timingSafeEqual } from "node:crypto";

export const config = { path: "/api/*" };

// Cadeaux de départ, utilisés tant que Melinux n'a rien modifié.
const SEED = [
  {
    "name": "Veste Courtney Rose",
    "shop": "Mad Peonies",
    "price": "85,00 €",
    "kind": "vetement",
    "size": "S/M",
    "color": "Imprimé faon, col et poignets roses",
    "url": "https://madpeonies.com/products/veste-courtney-rose?variant=54417038377288",
    "order": 1,
    "id": "veste-courtney-rose",
    "img": "img/veste-courtney-rose.jpg"
  },
  {
    "name": "Baskets Salomon XT-6 GTX",
    "shop": "Zalando",
    "price": "180,00 €",
    "kind": "chaussures",
    "size": "38,5",
    "color": "Bitter Chocolate / Iron / Vanilla Ice",
    "url": "https://www.zalando.fr/salomon-sportstyle-xt-6-gtx-unisex-baskets-basses-bitter-chocolateironvanilla-ice-sa515o01t-o13.html",
    "order": 2,
    "id": "salomon-xt6-gtx",
    "img": "img/salomon-xt6-gtx.jpg"
  },
  {
    "name": "Pull rayé vert et rose",
    "shop": "ASOS · JJXX",
    "price": "49,99 €",
    "kind": "vetement",
    "size": "M",
    "color": "Green Moss",
    "url": "https://www.asos.com/fr/jjxx/jjxx-pull-a-rayures-vertes-et-roses/prd/211265454",
    "order": 3,
    "id": "jjxx-pull-vert-rose",
    "img": "img/jjxx-pull-vert-rose.jpg"
  },
  {
    "name": "Pull oversize duveteux à rayures",
    "shop": "ASOS · COLLUSION",
    "price": "47,99 €",
    "kind": "vetement",
    "size": "M",
    "color": "Rayures multicolores, unisexe",
    "url": "https://www.asos.com/fr/collusion/collusion-pull-oversize-unisexe-a-col-rond-duveteux-a-rayures-multicolore/prd/211166012",
    "order": 4,
    "id": "collusion-pull-multicolore",
    "img": "img/collusion-pull-multicolore.jpg"
  }
];

const KINDS = ["vetement", "chaussures", "autre"];
const ID_RE = /^[A-Za-z0-9_-]{1,64}$/;
const TOKEN_RE = /^[A-Za-z0-9_-]{16,64}$/;
const MAX_IMG = 1_500_000; // octets

const data = () => getStore({ name: "noel", consistency: "strong" });
const imgs = () => getStore({ name: "noel-img", consistency: "strong" });

const json = (body, status = 200, extra = {}) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...extra },
  });
const fail = (status, error) => json({ error }, status);

const sha = (s) => createHash("sha256").update(String(s)).digest();

function adminState(req) {
  const real = process.env.ADMIN_CODE;
  if (!real) return "unset";
  const given = req.headers.get("x-admin-code") || "";
  return timingSafeEqual(sha(given), sha(real)) ? "ok" : "bad";
}

async function loadGifts(store) {
  const g = await store.get("gifts", { type: "json" });
  return Array.isArray(g) ? g : SEED;
}

function cleanText(v, max) {
  return typeof v === "string" ? v.trim().slice(0, max) : "";
}

function cleanGift(id, raw, order) {
  const name = cleanText(raw.name, 80);
  if (!name) return null;
  let url = cleanText(raw.url, 500);
  if (url && !/^https?:\/\//i.test(url)) url = "";
  return {
    id,
    name,
    shop: cleanText(raw.shop, 60),
    price: cleanText(raw.price, 40),
    kind: KINDS.includes(raw.kind) ? raw.kind : "vetement",
    size: cleanText(raw.size, 40),
    color: cleanText(raw.color, 80),
    url,
    img: typeof raw.img === "string" ? raw.img : "",
    order,
  };
}

// Reçoit une image en data:URI et la range dans le store d'images.
async function storeImage(giftId, dataUri) {
  const m = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(dataUri);
  if (!m) return null;
  const bytes = Buffer.from(m[2], "base64");
  if (bytes.length === 0 || bytes.length > MAX_IMG) return null;
  const key = giftId + "-" + Date.now().toString(36);
  await imgs().set(key, bytes, { metadata: { type: m[1] } });
  return "/api/img/" + key;
}

const validImgPath = (p) => p === "" || /^img\/[\w.-]+$/.test(p) || /^\/api\/img\/[\w-]+$/.test(p);

export default async (req) => {
  const url = new URL(req.url);
  const parts = url.pathname.replace(/^\/api\/?/, "").split("/").filter(Boolean);
  const method = req.method;
  const route = parts[0] || "";

  try {
    // --- Image envoyée par Melinux ---
    if (route === "img" && method === "GET" && parts[1]) {
      if (!/^[\w-]+$/.test(parts[1])) return fail(404, "introuvable");
      const hit = await imgs().getWithMetadata(parts[1], { type: "arrayBuffer" });
      if (!hit) return fail(404, "introuvable");
      return new Response(hit.data, {
        headers: {
          "content-type": (hit.metadata && hit.metadata.type) || "image/jpeg",
          "cache-control": "public, max-age=31536000, immutable",
        },
      });
    }

    const token = req.headers.get("x-token") || "";
    const tokenOk = TOKEN_RE.test(token);

    // --- Etat public : cadeaux + réservations ---
    if (route === "state" && method === "GET") {
      const store = data();
      const gifts = (await loadGifts(store)).slice().sort((a, b) => (a.order || 0) - (b.order || 0));
      const reservations = {};
      const { blobs } = await store.list({ prefix: "res/" });
      await Promise.all(
        blobs.map(async (b) => {
          const r = await store.get(b.key, { type: "json" });
          if (r && r.by) reservations[b.key.slice(4)] = { mine: tokenOk && r.by === token };
        })
      );
      return json({ gifts, reservations });
    }

    // --- Réserver ---
    if (route === "reserve" && method === "POST") {
      if (!tokenOk) return fail(400, "jeton invalide");
      const body = await req.json().catch(() => ({}));
      const id = body && body.id;
      if (typeof id !== "string" || !ID_RE.test(id)) return fail(400, "cadeau invalide");
      const store = data();
      if (!(await loadGifts(store)).some((g) => g.id === id)) return fail(404, "cadeau introuvable");
      const res = await store.setJSON("res/" + id, { by: token, at: Date.now() }, { onlyIfNew: true });
      if (res && res.modified === false) {
        const cur = await store.get("res/" + id, { type: "json" });
        if (cur && cur.by === token) return json({ ok: true });
        return fail(409, "déjà réservé");
      }
      return json({ ok: true });
    }

    // --- Annuler une réservation (la sienne, ou n'importe laquelle pour Melinux) ---
    if (route === "reserve" && method === "DELETE" && parts[1]) {
      const id = parts[1];
      if (!ID_RE.test(id)) return fail(400, "cadeau invalide");
      const store = data();
      const cur = await store.get("res/" + id, { type: "json" });
      if (!cur) return json({ ok: true });
      const admin = adminState(req) === "ok";
      if (!admin && !(tokenOk && cur.by === token)) return fail(403, "ce n'est pas ta réservation");
      await store.delete("res/" + id);
      return json({ ok: true });
    }

    // --- Espace Melinux ---
    if (route === "admin" || route === "gift") {
      const a = adminState(req);
      if (a === "unset") return fail(503, "ADMIN_CODE non réglé");
      if (a !== "ok") {
        await new Promise((r) => setTimeout(r, 500));
        return fail(401, "code incorrect");
      }

      if (route === "admin" && parts[1] === "check" && method === "POST") return json({ ok: true });

      const store = data();

      if (route === "admin" && parts[1] === "order" && method === "POST") {
        const body = await req.json().catch(() => ({}));
        const ids = Array.isArray(body.ids) ? body.ids : [];
        const gifts = await loadGifts(store);
        const byId = new Map(gifts.map((g) => [g.id, g]));
        const next = [];
        ids.forEach((i) => { if (byId.has(i)) { next.push(byId.get(i)); byId.delete(i); } });
        byId.forEach((g) => next.push(g));
        next.forEach((g, i) => { g.order = i + 1; });
        await store.setJSON("gifts", next);
        return json({ ok: true });
      }

      if (route === "gift" && parts[1] && method === "PUT") {
        const id = parts[1];
        if (!ID_RE.test(id)) return fail(400, "identifiant invalide");
        const raw = await req.json().catch(() => null);
        if (!raw || typeof raw !== "object") return fail(400, "données invalides");
        const gifts = await loadGifts(store);
        const idx = gifts.findIndex((g) => g.id === id);
        const order = idx >= 0 ? gifts[idx].order : gifts.reduce((m, g) => Math.max(m, g.order || 0), 0) + 1;
        const g = cleanGift(id, raw, order);
        if (!g) return fail(400, "le nom est obligatoire");
        if (g.img.startsWith("data:")) {
          const saved = await storeImage(id, g.img);
          if (!saved) return fail(400, "image invalide ou trop lourde");
          g.img = saved;
        } else if (!validImgPath(g.img)) {
          g.img = idx >= 0 ? gifts[idx].img : "";
        }
        if (idx >= 0) gifts[idx] = g; else gifts.push(g);
        await store.setJSON("gifts", gifts);
        return json({ ok: true, gift: g });
      }

      if (route === "gift" && parts[1] && method === "DELETE") {
        const id = parts[1];
        if (!ID_RE.test(id)) return fail(400, "identifiant invalide");
        const gifts = (await loadGifts(store)).filter((g) => g.id !== id);
        await store.setJSON("gifts", gifts);
        await store.delete("res/" + id);
        return json({ ok: true });
      }
    }

    return fail(404, "route inconnue");
  } catch (err) {
    console.error(err);
    return fail(500, "erreur serveur");
  }
};
